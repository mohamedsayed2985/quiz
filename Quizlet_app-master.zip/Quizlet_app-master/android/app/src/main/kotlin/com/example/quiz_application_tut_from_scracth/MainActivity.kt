package com.example.quiz_application_tut_from_scracth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
