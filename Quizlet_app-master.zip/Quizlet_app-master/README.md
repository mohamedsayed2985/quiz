Quiz Application in Flutter using GetX.

Presenting Quizlet application

https://github.com/Priyasha2002/Quizlet_app/assets/90889014/6ce492b8-c18f-4dfb-94eb-aacdc64a346b

